package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import entity.TipoEntity;
import repository.TipoRepository;
import service.TipoService;

public class App {

	// Atributos
	private static TipoService tipoService;
	private static Scanner scanner;

	// Constantes
	private static final String MENU_CADASTRAR = "1";
	private static final String MENU_EDITAR = "2";
	private static final String MENU_LISTAR_PELO_ID = "3";
	private static final String MENU_LISTAR_TODOS = "4";
	private static final String MENU_REMOVER = "5";
	private static final String MENU_SAIR = "0";

	private static void inicializaVariaveis() {
		tipoService = new TipoService();
		scanner = new Scanner(System.in);
	}

	private static String leituraTeclado() {
		String texto = scanner.next();
		return texto;
	}

	private static void exibeMenu() {
		System.out.println("MENU");
		System.out.println("Informe a opção abaixo:");
		System.out.println("1 - Cadastrar");
		System.out.println("2 - Editar");
		System.out.println("3 - Listar todos");
		System.out.println("4 - Listar pelo Id");
		System.out.println("5 - Remover");
		System.out.println("0 - Sair");
		System.out.println("");
		System.out.print("Opção: ");
	}

	private static void cadastrar() {
		System.out.println("Opção selecionada: Cadastrar");
		System.out.println("---------------------------------------");
		System.out.print("Digite o nome: ");
		String nome = leituraTeclado();

		TipoEntity tipoEntity = new TipoEntity(nome);
		tipoService.salvar(tipoEntity);
	}

	private static void editar() {
		System.out.println("Opção selecionada: Editar");
		System.out.println("---------------------------------------");

		imprimirTodos();
		System.out.print("Informe o id do tipo que você deseja editar: ");
		int id = Integer.parseInt(leituraTeclado());

		TipoEntity tipoEntity = tipoRepository.listarPeloId(id);
		if (tipoEntity != null) {
			System.out.print("Informe o nome: ");
			String nome = leituraTeclado();
			tipoEntity.setNome(nome);

			tipoService.salvar(tipoEntity);
		} else {
			System.out.println("O tipo com id " + id + " não foi encontrado");			
		}
	}

	private static void listarTodos() {
		System.out.println("Opção selecionada: Listar todos");
		System.out.println("---------------------------------------");
		imprimirTodos();
	}

	private static void listarPeloId() {
		System.out.println("Opção selecionada: Listar pelo id");
		System.out.println("---------------------------------------");

		imprimirTodos();
		System.out.print("Informe o id do tipo que você deseja listar: ");
		int id = Integer.parseInt(leituraTeclado());

		TipoEntity tipoEntity = tipoRepository.listarPeloId(id);
		if (tipoEntity != null)
			tipoEntity.imprimir();
	}

	private static void remover() {
		System.out.println("Opção selecionada: Remover");
		System.out.println("---------------------------------------");

		imprimirTodos();
		System.out.print("Informe o id do tipo que você deseja remover: ");
		int id = Integer.parseInt(leituraTeclado());

		tipoRepository.remove(id);
	}

	private static void imprimirTodos() {
		System.out.println("Tipos cadastrados:");
		System.out.println("");
		
		List<TipoEntity> tipos = tipoRepository.listarTodos();
		for (TipoEntity tipo : tipos) {
			tipo.imprimir();
			System.out.println("");
		}
	}

	private static void finalizar() {
		System.out.println("Finalizando a aplicação");
		scanner.close();
	}

	public static void main(String[] args) {

		inicializaVariaveis();

		String opcao;
		do {
			exibeMenu();
			opcao = leituraTeclado();
			switch (opcao) {
			case MENU_SAIR:
				finalizar();
				break;
			case MENU_CADASTRAR:
				cadastrar();
				break;
			case MENU_EDITAR:
				editar();
				break;
			case MENU_LISTAR_TODOS:
				listarTodos();
				break;
			case MENU_LISTAR_PELO_ID:
				listarPeloId();
				break;
			case MENU_REMOVER:
				remover();
				break;
			default:
				System.out.println("Opção inválida");
				break;
			}
		} while (!opcao.equals(MENU_SAIR));
	}
}
