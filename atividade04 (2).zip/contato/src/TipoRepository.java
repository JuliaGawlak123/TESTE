package repository;

import java.util.ArrayList;
import java.util.List;

import entity.TipoEntity;

public class TipoRepository {

	private List<TipoEntity> tipos;
	
	public TipoRepository() {
		this.tipos = new ArrayList<>();
	}
	
	private int geraIdAutomaticamente() {
		int id = 0;
		for (TipoEntity tipo : tipos) {
			if (tipo.getId() > id)
				id = tipo.getId();
		}
		return id++;
	}
	
	public boolean registroJaExiste(String nome) {
		boolean tipoJaCadastrado = false;
		for (TipoEntity tipo : tipos) {
			if (tipo.getNome().equalsIgnoreCase(nome)) {
				System.out.println("Tipo '" + nome + "' já cadastrado");
				tipoJaCadastrado = true;
				break;
			}
		}
		return tipoJaCadastrado;
	}
	
	public void inserir(TipoEntity tipoEntity) {
		tipoEntity.setId(geraIdAutomaticamente());
		this.tipos.add(tipoEntity);
	}
	
	public List<TipoEntity> listarTodos() {
		return this.tipos;
	}

	// editar
	// listarPeloId
	// listarTodos
	// remover
	// gerarIdAutomatimente
	// listarPeloNome

}
