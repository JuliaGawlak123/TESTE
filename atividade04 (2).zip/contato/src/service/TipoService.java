package service;

import java.util.List;

import entity.TipoEntity;
import repository.TipoRepository;

public class TipoService {

	private TipoRepository tipoRepository;
	
	public TipoService() {
		this.tipoRepository = new TipoRepository();
	}
	
	private boolean validaDuplicidadeDados(TipoEntity tipoEntity) {
		List<TipoEntity> tipos = tipoRepository.listarTodos();
		for (TipoEntity tipo : tipos) {
			if (tipoEntity.getNome().equals(tipo.getNome())) {
				return false;
			}
		}
		return true;
	}

	private boolean validaDados(TipoEntity tipoEntity) {
		// Validar dados obrigatórios
		if (tipoEntity.getNome() == null) {
			System.out.println("O nome não pode ser nulo");
			return false;
		} else if (tipoEntity.getNome().trim().equals("")) {
			System.out.println("O nome não pode ser nulo");
			return false;
		} else if (tipoEntity.getNome().length() > 50) {
			System.out.println("O nome não pode conter mais de 50 caracters");
			return false;
		}
		
		// Validar duplicidade de dados
		if (!validaDuplicidadeDados(tipoEntity)) {
			System.out.println("Registro em duplicidade");
			return false;
		}
		
		return true;
	}
	
	public void salvar(TipoEntity tipoEntity) {
		if ( validaDados(tipoEntity) ) {
			if (tipoEntity.getId() == null) {
				tipoRepository.inserir(tipoEntity);
			} else {
				tipoRepository.atualiza(tipoEntity);
			}
		}
	}
}
