package repository;

import java.util.ArrayList;
import java.util.List;

import entity.TipoEntity;

public class TipoRepository {

	private List<TipoEntity> tipos;
	
	public TipoRepository() {
		this.tipos = new ArrayList<>();
	}
	
	private int geraIdAutomaticamente() {
		int id = 0;
		for (TipoEntity tipo : tipos) {
			if (tipo.getId() > id)
				id = tipo.getId();
		}
		return id++;
	}
	
	public boolean registroJaExiste(String nome) {
		boolean tipoJaCadastrado = false;
		for (TipoEntity tipo : tipos) {
			if (tipo.getNome().equalsIgnoreCase(nome)) {
				System.out.println("Tipo '" + nome + "' já cadastrado");
				tipoJaCadastrado = true;
				break;
			}
		}
		return tipoJaCadastrado;
	}
	
	public void inserir(TipoEntity tipoEntity) {
		tipoEntity.setId(geraIdAutomaticamente());
		this.tipos.add(tipoEntity);
		System.out.println("Tipo cadastrado com sucesso!");
	}
	
	public List<TipoEntity> listarTodos() {
		System.out.println("Tipos encontrados: " + tipos.size());
		return this.tipos;
	}

	public void remove(TipoEntity tipoEntity) {
		this.tipos.remove(tipoEntity);
		System.out.println("Tipo removido com sucesso!");
	}
	
	public void remove(Integer id) {
		for (TipoEntity tipoEntity : tipos) {
			if (tipoEntity.getId().equals(id)) {
				remove(tipoEntity);
				System.out.println("Tipo removido com sucesso!");
				break;
			}
		}
	}

	public TipoEntity listarPeloId(int id) {
		for (TipoEntity tipoEntity : tipos) {
			if (tipoEntity.getId().equals(id)) {
				System.out.println("Tipo encontrado com sucesso!");
				return tipoEntity;
			}
		}
		System.out.println("O tipo com id " + id + " não foi encontrado!");
		return null;
	}

	public void atualiza(TipoEntity tipoEntity) {
		for (TipoEntity tipo : tipos) {
			if (tipoEntity.getId().equals(tipo.getId())) {
				tipo = tipoEntity;
			}
			System.out.println("O tipo atualizado com sucesso!");
		}
	}
}
